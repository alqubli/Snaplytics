# PostgreSQL Snaplytics
قاعدة البيانات + الجداول الأساسية