# Frontend React Snaplytics
واجهة المستخدم الأساسية