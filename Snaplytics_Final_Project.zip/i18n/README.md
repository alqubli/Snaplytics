# Languages i18n Snaplytics
English / Arabic / Spanish / French / Korean / Chinese / Japanese